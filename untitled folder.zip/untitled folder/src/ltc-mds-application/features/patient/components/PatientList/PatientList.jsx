import React, { useState } from 'react';
import PropTypes from 'prop-types';

import Table from 'terra-table';
import StatusView from 'terra-status-view';
import ApplicationLoadingOverlay from 'orion-application/lib/application-loading-overlay';
import LoadingOverlay from 'terra-overlay/lib/LoadingOverlay';
import Overlay from 'terra-overlay';
import OverlayContainer from 'terra-overlay/lib/OverlayContainer';

import classNames from 'classnames/bind';
import styles from  './PatientList.scss';
import { useSelector } from 'react-redux';
import { ApplicationIntlContext } from 'orion-application/lib/application-intl';



const cx = classNames.bind(styles);

const propTypes = {
  patientList: PropTypes.any
}

const PatientList = () => {
  const intl = React.useContext(ApplicationIntlContext);
  const {patientList, hasError, isPatientListLoading, isPatientSuccess, errorMessage} = useSelector(state=>state.patientList);
  console.log(patientList);

  const [selectedKey, setSelectedKey] = useState([]);
  const createCell = (cell) => ({ key: cell.key, children: cell.title });

  const createCellsForRow = (cells) => cells.map((cell) => createCell(cell));

  const createRows = (data) => data.map((childItem) => createRow(childItem));

  const handleRowToggle = (event, metaData) => {
    event.preventDefault();
    if (selectedKey !== metaData.key) {
      setSelectedKey(metaData.key);
    }
    selectPatient(metaData.patientData);
  }; // Row toggle select


  const createRow = (rowData) => ({
    key: rowData.key,
    cells: createCellsForRow(rowData.cells),
    toggleAction: {
      metaData: { key: rowData.key, patientData: rowData.patientData },
      onToggle: handleRowToggle,
      isToggled: selectedKey === rowData.key,
      toggleLabel: rowData.toggleText,
    },
  });

  const removeTime = (date = new Date()) => {
    if(!(date instanceof Date)){
      date = new Date(date);
    }
    return new Date(
      date.getFullYear(),
      date.getMonth(),
      date.getDate()
    ).toDateString();
  }

  const addOverlay = () => {
    if(isPatientListLoading){
      return <LoadingOverlay
              isOpen={isPatientListLoading}
              isAnimated
              isRelativeToContainer={true}
              zIndex="6000"
            />
    } else {
        return <Overlay 
          isOpen={isPatientSuccess && patientList.length == 0} 
          isRelativeToContainer={true} 
          zIndex="6000">
          <p>No Patients found</p>
        </Overlay>
    }
  }

  // const selectPatient = (patient) => {
  //   /**call PATIENT DETAIL action to set selected patient */
  //   console.log(patient);
  // }

  const selectPatient = (patient) => {
    //TODO: import setSelectedPatient action from actions file
    //TODO: call setSelectedPatient
    //TODO: rename selectedPatientLoading to setSelectedPatient 
      if(patient){
        dispatch(selectedPatientLoading(selectedPatient,orionRequestor));
      }
    console.log(patient);

  }
  if(hasError){
    const errorMessageIntl = intl.formatMessage({ id: errorMessage });
    return <StatusView variant="error" message={errorMessageIntl} isGlyphHidden />;
  }

  if (isPatientListLoading) {
    return   <LoadingOverlay
              isOpen={isPatientListLoading}
              isAnimated
              message="Loading patient list"
              isRelativeToContainer={true}
              zIndex="6000"
            />
  }

  var patientListRowData = [];

  patientList.forEach((patient, index) => {
    var obj = {
      key: patient.patientId,
      toggleText: patient.nameFullFormatted,
      discloseText: patient.nameFullFormatted,
      primaryIndex: 1,
      cells: [
        {
          key: "unique-" + index + "-0",
          title: patient.nameFullFormatted,
        },
        {
          key: "unique-" + index + "-1",
          title: patient.patientIdentifier,
        },
        {
          key: "unique-" + index + "-2",
          title: patient.buildingName,
        },
        {
          key: "unique-" + index + "-3",
          title: removeTime(patient.admissionDateTime),
        },
      ],
      patientData: patient,
    };
    patientListRowData.push(obj);
  });

  return (
    <React.Fragment>
        <OverlayContainer overlay={addOverlay()}>
          <Table
            summaryId="standard-table"
            summary="This table has standard padding."
            numberOfColumns={3}
            cellPaddingStyle="standard"
            dividerStyle="horizontal"
            rowStyle="toggle"
            headerData={{
              cells: [
                { id: 'resident-name', key: 'name', children: 'Resident Name' },
                { id: 'mrn', key: 'mrn', children: 'MRN' },
                { id: 'location', key: 'location', children: 'Location' },
                { id: 'admission-date', key: 'admission-date', children: 'Admission Date' },
              ],
            }}
            bodyData={[
              {
                rows: createRows(patientListRowData),
              },
            ]}
          />
       </OverlayContainer>
    </React.Fragment>
  )
}

PatientList.propTypes = propTypes;

export default PatientList;
