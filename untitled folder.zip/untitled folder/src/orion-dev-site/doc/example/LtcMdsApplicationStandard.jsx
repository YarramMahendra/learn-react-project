import React from 'react';
import OrionRequestorMockProvider from 'orion-application/lib/orion-requestor/OrionRequestorMockProvider';
import { LtcMdsApplicationContainer } from '../../../ltc-mds-application/features/app';

// eslint-disable-next-line import/no-extraneous-dependencies, import/no-unresolved, import/extensions

export default () => (
  <OrionRequestorMockProvider
    mock={(instance) => {
      instance.onGet().reply(200, {
        data: 'Example Data.',
      });
    }}
  >
    <LtcMdsApplicationContainer />
  </OrionRequestorMockProvider>
);
