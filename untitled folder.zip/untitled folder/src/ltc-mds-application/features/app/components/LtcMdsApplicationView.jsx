import React from 'react';
import PropTypes from 'prop-types';
import { injectIntl, intlShape } from 'react-intl';
import { ApplicationIntlContext } from 'orion-application/lib/application-intl';
import ContentContainer from 'terra-content-container';
import Header from 'terra-action-header';
import Spacer from 'terra-spacer';
import { MdsDashboard } from './MdsDashboard';
import { useSelector } from 'react-redux';
import { AssessmentFilter } from '../../patient/components/AssessmentFilter/AssessmentFilter';


const propTypes = {
  // facilityList: PropTypes.any,
};

const LtcMdsApplicationView = () => {
  const intl = React.useContext(ApplicationIntlContext);

  /**check if patient is selected or not */

  const headerTitle = intl.formatMessage({ id: 'DASHBOARD_TITLE' });

  return (
    <ContentContainer header={<Header title={headerTitle} />}>
      <Spacer paddingTop="large+1" paddingBottom="large+1" paddingLeft="large+1" paddingRight="large+1">
        {/* <MdsDashboard/>  */}
        <AssessmentFilter/>
        {/* *load resident view if patient is selected */}
      </Spacer>
    </ContentContainer>
  );
 
};

LtcMdsApplicationView.propTypes = propTypes;

export default injectIntl(LtcMdsApplicationView);
