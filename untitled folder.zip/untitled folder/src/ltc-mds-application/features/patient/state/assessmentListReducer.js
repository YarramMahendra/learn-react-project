import {
  GET_ASSESSMENT_LIST_SUCCESS,
  GET_ASSESSMENT_LIST_FAIL,
  SET_ASSESSMENT_LIST_LOADING
} from '../../../constants/ActionTypes';
  
  const INITIAL_STATE = {
      assessmentList: [],
      isAssessmentSuccess: false,
      isAssessmentListLoading: false,
      errorMessage: "",
      hasError: false
  };
  
  export default function AssessmentListReducer(state = INITIAL_STATE, action) {
    if (!action) {
      return state;
    }
  
    switch (action.type) {
      case GET_ASSESSMENT_LIST_SUCCESS: {
        return {
          ...state,
          assessmentList: action.payload.assessmentList,
          isAssessmentSuccess: true,
          hasError: false,
          errorMessage:"",
          isAssessmentListLoading: false
        };
      }
  
      case GET_ASSESSMENT_LIST_FAIL: {
        return {
          ...state,
          isAssessmentSuccess: false,
          isAssessmentListLoading: false,
          hasError: true,
          errorMessage: "GET_ASSESSMENT_LIST_FAIL"
        };
      }

      case SET_ASSESSMENT_LIST_LOADING: {
        return {
          ...state,
          isAssessmentListLoading: action.payload.loading
        };
      }
  
      default:
        return state;
    }
  }