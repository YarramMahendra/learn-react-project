import React from 'react';

import {MdsDashboard} from '../index';

describe('<MdsDashboard />', () => {});
