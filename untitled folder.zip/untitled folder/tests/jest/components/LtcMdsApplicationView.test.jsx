import React from 'react';
import { mockIntl } from 'terra-enzyme-intl';
import { ApplicationIntlContext } from 'orion-application/lib/application-intl';
import LtcMdsApplicationView from '../../../src/ltc-mds-application/components/LtcMdsApplicationView';

it('should render a LtcMdsApplicationView with no data', () => {
  jest.spyOn(React, 'useContext').mockImplementation((contextType) => {
    if (contextType === ApplicationIntlContext) {
      return mockIntl;
    }
    return undefined;
  });
  const ltcMdsApplicationView = shallow(<LtcMdsApplicationView />);
  expect(ltcMdsApplicationView.first().shallow()).toMatchSnapshot();
});

it('should render a LtcMdsApplicationView that has succeeded with a valid MillenniumLtcMdsEngine', () => {
  jest.spyOn(React, 'useContext').mockImplementation((contextType) => {
    if (contextType === ApplicationIntlContext) {
      return mockIntl;
    }
    return undefined;
  });
  const ltcMdsApplicationView = shallow(<LtcMdsApplicationView exampleData="LtcMdsApplication" />);
  expect(ltcMdsApplicationView.first().shallow()).toMatchSnapshot();
});
