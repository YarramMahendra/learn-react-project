export * from './PatientDetail';
