import React from 'react';
import LtcMdsApplicationContainer from '../../../src/ltc-mds-application/components/LtcMdsApplicationContainer';

it('should render a LtcMdsApplicationContainer with a default LtcMdsApplicationView', () => {
  const testContainer = <LtcMdsApplicationContainer />;
  expect(shallow(testContainer)).toMatchSnapshot();
});
