import { AppConstants } from "../constants/AppConstants";
import moment, { max } from "moment";
import "moment-timezone";

/**
 * Function to take a local date and convert it to a UTC date time object in ISO notation.
 * The localdate is considered to be in facility time zone.
 *
 * @param localDate A date string with no timezone information in it
 * @param facilityTimeZone The facility time zone which is to be applied to the given localDate
 */
export function convertToUTCDateTime(localDate, facilityTimeZone) {
    if (localDate === null) {
      return AppConstants.EMPTY_STRING;
    } else {
      moment.tz.setDefault(facilityTimeZone);
      let localDateInFacilityTimezone = moment(localDate);
      moment.tz.setDefault();
      return localDateInFacilityTimezone.toISOString();
    }
  }