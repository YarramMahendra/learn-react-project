import { combineReducers } from "redux";
import dashboardFilterReducer from "./features/app/state/dashboardFilterReducer";
// import { PatientDetail } from "./features/patient/components";

import patientDetailReducer from "./features/patient/state/patientDetailReducer";
import patientListReducer from "./features/patient/state/patientListReducer";
    // import PatientDetailReducer from "./features/patient/components/PatientDetail/PatientDetail";
import AssessmentListReducer from './features/patient/state/assessmentListReducer'

// Root reducer to use throughout the app
// Makes it easier for importing/using instead of declaring all reducers
const rootReducer = combineReducers({
    dashboardFilter:dashboardFilterReducer,
    patientList: patientListReducer,
    PatientDetail:patientDetailReducer,
    assessmentList:AssessmentListReducer

});

export default rootReducer;
