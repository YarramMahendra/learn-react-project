
/** Store assessments for the selected patient/resident */
import {
    SET_MDS_STATUS_SUCCESS,
    SET_MDS_STATUS_FAIL,
    SET_MDS_STATUS_FILTER_PARAMS,
    SET_MDS_STATUS_FILTER_LOADING
  } from '../../../constants/ActionTypes';
  import { AppConstants } from '../../../constants/AppConstants';

  
    
    const INITIAL_STATE = {
        mockMdsStatusData:AppConstants.mdsStatusOptions,
        mdsStatusFilters: {
          mdsStatusId:'',
          ardStartDate:new Date(new Date().setDate(new Date().getDate() - 30)),
          ardEndDate: new Date()
        },
        hasError: false,
        isLoading: true,
      isSuccess: false,
      errorMessage: ""
    };
    export default function patientDetailReducer(state = INITIAL_STATE, action) {
      // if (!action) {
      //   return state;
      // }
    
      switch (action.type) {
      //   case SET_MDS_STATUS_SUCCESS: {
      //     return {
      //       ...state,
      //       mockMdsStatusData: action.payload.mockMdsStatusData,
      //       mdsStatusFilters:{
      //         isMdsStatusLoading: false,
      //         mdsStatusId: action.payload.mockMdsStatusData[0].id,
      //         ardStartDate: new Date(new Date().setDate(new Date().getDate() - 30)),
      //         ardEndDate: new Date(),
      //       },
      //       isSuccess: true, 
      //     };
      //   }
    
        // case SET_MDS_STATUS_FAIL: {
        //   return {
        //     ...state,
        //     isSuccess: false,
        //     isLoading: false,
        //     hasError: true,
        //     errorMessage: "SET_MDS_STATUS_FAIL"
        //   };
        // }
  
  
        // case   SET_MDS_STATUS_FILTER_PARAMS: {
        //   return {
        //     ...state,
        //     hasError: false,
        //     mdsStatusFilters:{
        //       ...state.mdsStatusFilters,
        //       ...action.payload
        //     }
        //   }
        // }
    
        // case SET_MDS_STATUS_FILTER_LOADING: {
        //   return {
        //     ...state,
        //     mdsStatusFilters:{
        //       ...state.mdsStatusFilters,
        //       isMSdsStatusLoading: action.payload.loading
        //     } 
        //   };
        // }
    
        default:
          return state;
      }
    }
    