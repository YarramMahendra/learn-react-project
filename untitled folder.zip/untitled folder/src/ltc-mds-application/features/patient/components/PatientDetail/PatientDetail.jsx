import React from 'react';
import PropTypes from 'prop-types';

import styles from './PatientDetail.scss';
import { AsseessmentList } from '../AssessmentList';
import { AssessmentFilter } from '../AssessmentFilter';

const propTypes = {
  prop:  PropTypes.string
}

const PatientDetail = ({prop = 'default value'}) => {
  return <div className={styles.PatientDetail}>PatientDetail {prop}
  <AssessmentFilter/>
  <AsseessmentList/>
  
  </div>;
}

PatientDetail.propTypes = propTypes;

export default PatientDetail;
