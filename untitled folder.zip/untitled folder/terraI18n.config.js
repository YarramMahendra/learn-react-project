const aggregateOptions = {
  baseDir: __dirname,
  directories: ['node_modules/*/translations', 'node_modules/*/node_modules/*/translations'],
  locales: ['en', 'en-US', 'en-GB', 'de', 'es', 'fr', 'pt', 'nl', 'sv'],
  outputDir: './aggregated-translations',
};

module.exports = aggregateOptions;
