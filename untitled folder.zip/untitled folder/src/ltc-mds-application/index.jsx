import React from 'react';
import ReactDOM from 'react-dom';
import { LtcMdsApplicationApplication } from './features/app';

ReactDOM.render(<LtcMdsApplicationApplication />, document.getElementById('root'));
