export function getDropDownValues(componentName){
    switch(componentName){
        case 'MDS_STATUS' : 
        return [
        {
            "id": "5466565",
            "name": "Open"
        },
        {
            "id": "6577567",
            "name": "Closed"
        },
        {
            "id": "76766565",
            "name": "Signature-Ready"
        },
        {
            "id": "995786",
            "name": "Zip-Ready"
        },
        {
            "id": "8676786",
            "name": "CMS pending"
        },]
        case 'MDS_ASSESSMENT' : 
        return [
        {
            "id": "5546655",
            "name": "Annual assessment"
        },
        {
            "id": "1234343",
            "name": "Quarterly assessment"
        },
        {
            "id": "32444353",
            "name": "Entry tracking"
        },
        
] 





}
}