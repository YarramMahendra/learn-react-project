import React from 'react';

import {PatientList} from '../PatientList';

describe('<PatientList />', () => {});
