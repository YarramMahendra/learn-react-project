import React from 'react';

import {PatientDetail} from '../PatientDetail';

describe('<PatientDetail />', () => {});
