Terra.describeViewports('LtcMdsApplication', ['tiny', 'small', 'medium', 'large', 'huge', 'enormous'], () => {
  describe('No Data available', () => {
    it('validates when no data is available', () => {
      browser.url('/orion-dev-site/raw/tests/Millennium-LTC-MDS-Js/ltc-mds-application-no-data');
      Terra.validates.element('no data available');
    });
  });
});
