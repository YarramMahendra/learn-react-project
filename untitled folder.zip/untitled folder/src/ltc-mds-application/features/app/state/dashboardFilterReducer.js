import {
  SET_USER_FACILITIES_SUCCESS,
  SET_USER_FACILITIES_FAIL,
  SET_LOCATION_LIST_SUCCESS,
  SET_LOCATION_LIST_FAIL,
  SET_FILTER_PARAMS,
  SET_FILTER_LOADING,
  GET_SELECTED_PATIENT_LAODONG

} from '../../../constants/ActionTypes';
import { AppConstants } from '../../../constants/AppConstants';
  
const INITIAL_STATE = {
    userFacilities: [],
    locations:[],
    filters: {
      isFilterLoading: true,
      facilityId:null,
      nurseUnits: [],
      startDate:null,
      endDate: null,
      timeZone:null,
      reportType: AppConstants.REPORT_TYPE.ADMISSION
    },
    hasError: false,
    isLoading: true,
    isSuccess: false,
    errorMessage: ""
  };
  
  export default function dashboardFilterReducer(state = INITIAL_STATE, action) {
    if (!action) {
      return state;
    }
  
    switch (action.type) {
      case SET_USER_FACILITIES_SUCCESS: {
        return {
          ...state,
          userFacilities: action.payload.userFacilities,
          locations: action.payload.nurseUnits,
          filters:{
            isFilterLoading: false,
            facilityId: action.payload.userFacilities[0].id,
            nurseUnits: action.payload.nurseUnits.map(unit=>unit.id),
            startDate: new Date(new Date().setDate(new Date().getDate() - 30)),
            endDate: new Date(),
            timeZone: action.payload.userFacilities[0].timeZone,
            reportType: AppConstants.REPORT_TYPE.ADMISSION
          },
          isSuccess: true,
          isLoading: false,
          errorMessage: ""
        };
      }
  
      case SET_USER_FACILITIES_FAIL: {
        return {
          ...state,
          isSuccess: false,
          isLoading: false,
          hasError: true,
          errorMessage: "SET_USER_FACILITIES_FAIL"
        };
      }

      case SET_LOCATION_LIST_SUCCESS: {
        return {
          ...state,
          locations: action.payload.locationList,
          filters:{
            ...state.filters,
            ...action.payload.filters,
            isFilterLoading: false,
            nurseUnits: []
          },
          isSuccess: true,
          isLoading: false,
          errorMessage: ""
        };
      }
  
      case SET_LOCATION_LIST_FAIL: {
        return {
          ...state,
          isSuccess: false,
          isLoading: false,
          hasError: true,
          errorMessage: "SET_LOCATION_LIST_FAIL"
        };
      }

      case SET_FILTER_PARAMS: {
        return {
          ...state,
          hasError: false,
          filters:{
            ...state.filters,
            ...action.payload
          }
        }
      }
  
      case SET_FILTER_LOADING: {
        return {
          ...state,
          filters:{
            ...state.filters,
            isFilterLoading: action.payload.loading
          } 
        };
      }

      /**set selected patient case */

      case GET_SELECTED_PATIENT_LAODONG:{
        return{
          ...state,
          selectedPatient:{
            id:"",
            name:"",
            ...state.selectedPatient,
            isselectedPatientLoading:action.payload.loading,
            isSuccess: true,
            errorMessage: "GET_SELECTED_PATIENT_LAODONG"
          }
        }
      }
  
      default:
        return state;
    }
  }
  