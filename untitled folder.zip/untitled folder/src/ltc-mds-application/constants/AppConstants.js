export const AppConstants = {
    CARET: "^",
    HYPHEN: "-",
    DOT_SEPERATOR: ".",
    EMPTY_STRING: "",
    EMPTY_SPACE: " ",
    COMMA: ",",
    NO_DATA_PROVIDED: "--",
    ZERO: "0",
    ONE: "1",
    DATE_TIME: {
      DATE_PICKER_FORMAT: "YYYY-MM-DD",
      DATE_FORMAT_2: "YYYY/MM/DD",
      MONTH_DAY_YEAR_FORMAT: "mm/dd/yyyy",
      MONTH_YEAR_FORMAT: "mm/yyyy",
      YEAR_FORMAT: "yyyy",
      TIME_24HRS_FORMAT: "HH:mm",
      EXPORT_FORMAT_ONE: "YYYYMMDD",
      EXPORT_FORMAT_TWO: "YYYYMM",
      EXPORT_FORMAT_THREE: "YYYY"
    },
    MINUS_ONE: "-1",
    D0150: "D0150",
    D0160_1: "D0160_1",
    D0160_2: "D0160_2",
  
    ERROR_TYPES: {
      NO_SCORE: "noScore",
      NOT_CALCULATED: "notCalculated",
      IS_CHANGED: "isChanged"
    },
  
    LOCATION_HASH: "#/",
    INITAL_NAVIGATION_SUBSECTION_INDEX: 0,
  
    REPORT_TYPE: {
      ADMISSION: "ADMISSION",
      DISCHARGE: "DISCHARGE"
    },
  
    EXPORT_STATUS: {
      SIGNED: "Signed",
      EXPORTED: "Exported",
      EXPORT_FAILED: "Export Failed"
    },
  
    VFC_SCORE_COL: {
      ADM: "ADM",
      DIS: "DIS",
      GOAL: "GOAL"
    },
  
    CHECKBOX: {
      CHECKED: "1",
      UN_CHECKED: "0"
    },
    
      mdsStatusOptions:[
      
    {
      "id": "5466565",
      "mdsStatus": "Open"
  },
    {
        "id": "6577567",
        "mdsStatus": "Closed"
    },
    {
        "id": "76766565",
        "mdsStatus": "Signature-Ready"
    },
    {
        "id": "995786",
        "mdsStatus": "Zip-Ready"
    },
    {
        "id": "8676786",
        "mdsStatus": "CMS pending"
    }],
  
    CERNER_CORRELATION_ID_HEADER: "cerner-correlation-id",
  
    STARTED: "STARTED",
    NOT_STARTED: "NOT_STARTED",
    COMPLETED: "COMPLETED",
    FAILED: "FAILED",
  
    COLUMNS: {
      ADM: "ADM",
      DIS: "DIS"
    }
  };
  