import React from 'react';
import { LtcMdsApplicationApplication } from '../../ltc-mds-application/features/app';
// eslint-disable-next-line import/no-extraneous-dependencies, import/no-unresolved, import/extensions

const DocPage = () => (
  <LtcMdsApplicationApplication />
);

export default DocPage;
