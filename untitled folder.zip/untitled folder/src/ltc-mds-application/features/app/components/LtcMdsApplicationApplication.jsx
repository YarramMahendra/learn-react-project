import React from 'react';
// import { injectIntl } from 'react-intl';
// import '@formatjs/intl-locale/polyfill';
import { Provider } from 'react-redux';

import ApplicationBase from 'orion-application/lib/application-base';
import { ApplicationSessionProvider } from 'orion-application/lib/application-session';
import ApplicationSessionMockProvider from "orion-application/lib/application-session/ApplicationSessionMockProvider"; //when rails engine is not linked
import OrionRequestorMockProvider from 'orion-application/lib/orion-requestor/OrionRequestorMockProvider';
import ApplicationNavigation from 'orion-application/lib/application-navigation';
// import { Date } from 'core-js';
import LtcMdsApplicationContainer from './LtcMdsApplicationContainer';
// import appTranslations from '../../../aggregated-translations/en-US';

import store from '../../../store';
import mockFacilities from '../../../data/mock/facility-list.json';
import mockLocations from '../../../data/mock/location-list.json';
import mockPatientList from '../../../data/mock/patient-list.json';



const LtcMdsApplicationApplication = () => {
  // const {
  //   date,
  //   intl, // Injected by `injectIntl`
  // } = props;
  return (
    <ApplicationBase
      locale="en"
      applicationName="MDS Intelligence"
      applicationVersion="1.0.0"
      applicationAboutPageUrl="https://github.cerner.com/ExtendedCareLTC/Millennium-LTC-MDS-Js.git"
      applicationHelpPageUrl="https://github.cerner.com/ExtendedCareLTC/Millennium-LTC-MDS-Js.git"
      renderSessionProvider={children => (
        <ApplicationSessionMockProvider
        user={{
          username: "SK102466",
          firstName: "Supriya",
          lastName: "Kijekkar"
        }}
      >
        {children}
      </ApplicationSessionMockProvider>
      )}
    >
      <ApplicationNavigation>
         <OrionRequestorMockProvider
             mock={(instance) => { 
               instance.onGet().reply(200, { 
                 data: {mockFacilities,mockLocations, mockPatientList}
               }); 
             }} 
           > 
           <Provider store={store}>
            <LtcMdsApplicationContainer />
           </Provider>
         </OrionRequestorMockProvider> 
      </ApplicationNavigation>
    </ApplicationBase>
  );
};

// LtcMdsApplicationApplication.propTypes = {
//   intl: intlShape.isRequired,
// };

export default LtcMdsApplicationApplication;
