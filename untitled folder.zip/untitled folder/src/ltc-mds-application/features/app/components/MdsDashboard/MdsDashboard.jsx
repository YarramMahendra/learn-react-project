import React, { useContext, useEffect, useState } from 'react';
import PropTypes from 'prop-types';

import styles from './MdsDashboard.scss';
import classNames from 'classnames/bind';

import DashboardFilter from '../DashboardFilter/DashboardFilter';
import PatientList from '../../../patient/components/PatientList/PatientList';

const cx = classNames.bind(styles);

const propTypes = {
  facilityList: PropTypes.any
}

const MdsDashboard = () => {
  const [temp,setTemp] = useState(false);
  return (
    <React.Fragment>
      <DashboardFilter />
      <PatientList />
      {/**button click to go to patient detail page */}
      
    </React.Fragment>
  )
}

MdsDashboard.propTypes = propTypes;

export default MdsDashboard;
