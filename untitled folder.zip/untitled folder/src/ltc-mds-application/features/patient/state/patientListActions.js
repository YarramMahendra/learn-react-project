import {
    GET_PATIENT_LIST_SUCCESS,
    GET_PATIENT_LIST_FAIL,
    SET_PATIENT_LIST_LOADING
  } from '../../../constants/ActionTypes';
import { AppConstants } from '../../../constants/AppConstants';
import { convertToUTCDateTime } from '../../../utils/DateTimeUtil';
  
  const jsonHeaders = (_requestData, headers) => {
    headers.Accept = "application/json";
  };
  const MAX_RETRIES = 0;
  
  function constructUrl(reportFilters) {
    const nurseUnitQueryParameters = reportFilters.nurseUnits
      .filter(nurseUnit=>nurseUnit != 'ALL')
      .map(nurseUnits => `${encodeURIComponent("nurseUnits[]")}=${nurseUnits}`)
      .join("&");
    const url = `/facilities/${
      reportFilters.facilityId
    }/patients?${nurseUnitQueryParameters}&startDate=${convertToUTCDateTime(
      reportFilters.startDate,
      reportFilters.timeZone
    )}&endDate=${convertToUTCDateTime(
      reportFilters.endDate,
      reportFilters.timeZone
    )}&reportType=${AppConstants.REPORT_TYPE.ADMISSION}&timeZone=${
      reportFilters.timeZone
    }`;
    return url;
  }
  
  export function getPatientList(filters, orionRequestor) {
      var url = constructUrl(filters);
      // log.info("get facilities for logged in User " + url);
      return dispatch => {
          dispatch(updatePatientListLoading(true));
          const { request } = orionRequestor.get({
          url: url
          });
          request
          .then(response => {
            //for mock data
            const patients = response.data.data.mockPatientList.recordData.patients;
            //for actual api calls
            // const patients = response.data.recordData.patients;
             dispatch(getPatientListSuccess(patients));
          })
          .catch(error => {
              // log.error(JSON.stringify(error));
              return dispatch(getPatientListFailure(error));
          });
      };
    }
  
  const getPatientListSuccess = (data) => {
    return {
      type: GET_PATIENT_LIST_SUCCESS,
      payload: {
        patients: data
      }
    };
  };
  
  const getPatientListFailure = data => {
    return {
      type: GET_PATIENT_LIST_FAIL,
      payload: {}
    };
  };
  
  export function updatePatientListLoading(isLoading) {
    return {
      type: SET_PATIENT_LIST_LOADING,
      payload: {
        loading: isLoading
      }
    };
  }
  