import {
    GET_PATIENT_LIST_SUCCESS,
    GET_PATIENT_LIST_FAIL,
    SET_PATIENT_LIST_LOADING,
    SET_SELEECTED_PATIENT_LOADING
  } from '../../../constants/ActionTypes';
    
    const INITIAL_STATE = {
        patientList: [],
        isPatientSuccess: false,
        isPatientListLoading: false,
        errorMessage: "",
        hasError: false
    };
    
    export default function patientListReducer(state = INITIAL_STATE, action) {
      if (!action) {
        return state;
      }
    
      switch (action.type) {
        case GET_PATIENT_LIST_SUCCESS: {
          return {
            ...state,
            patientList: action.payload.patients,
            isPatientSuccess: true,
            hasError: false,
            errorMessage:"",
            isPatientListLoading: false
          };
        }
    
        case GET_PATIENT_LIST_FAIL: {
          return {
            ...state,
            isPatientSuccess: false,
            isPatientListLoading: false,
            hasError: true,
            errorMessage: "GET_PATIENT_LIST_FAIL"
          };
        }
  
        case SET_PATIENT_LIST_LOADING: {
          return {
            ...state,
            isPatientListLoading: action.payload.loading
          };
        }

        
        case SET_SELEECTED_PATIENT_LOADING: {
          return {
            ...state,
            isPatientListLoading: true,
            
          }
        }
    
        default:
          return state;
      }
    }
    