const jestConfig = require('@cerner/jest-config-terra');

module.exports = {
  ...jestConfig,
  setupFiles: [
    './jest.enzymeSetup.js',
  ],
  // globalSetup: './jestglobalsetup.js',
  // This allows jest to resolve files from the generated aggregated-translations in addition to node_modules
  moduleDirectories: [
    'aggregated-translations',
    'node_modules',
  ],
  snapshotSerializers: [
    'enzyme-to-json/serializer',
  ],
  globalSetup: './jestglobalsetup.js',
};
