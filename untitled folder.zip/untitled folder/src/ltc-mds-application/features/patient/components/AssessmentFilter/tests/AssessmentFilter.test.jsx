import React from 'react';

import {AssessmentFilter} from '../AssessmentFilter';

describe('<AssessmentFilter />', () => {});
