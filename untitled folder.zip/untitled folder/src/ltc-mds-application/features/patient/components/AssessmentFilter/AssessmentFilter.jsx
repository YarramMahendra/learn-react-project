
import React from 'react';
// import { useEffect, useState } from 'react';
import IconEdit from 'terra-icon/lib/icon/IconEdit';
import Button from 'terra-button/lib/Button';
import classNames from 'classnames/bind';
import LoadingOverlay from 'terra-overlay/lib/LoadingOverlay';
import Overlay from 'terra-overlay';
import OverlayContainer from 'terra-overlay/lib/OverlayContainer';
import DatePickerField from 'terra-date-picker/lib/DatePickerField';
import SingleSelectField from 'terra-form-select/lib/SingleSelectField';
import SearchSelectField from 'terra-form-select/lib/SearchSelectField';
import MultiSelect from 'terra-form-select/lib/MultiSelect';
import styles from './AssessmentFilter.scss';
import Header from 'terra-action-header';
import { ApplicationIntlContext } from 'orion-application/lib/application-intl';
import  { useContext, useEffect, useState } from 'react';
import { OrionRequestorContext } from 'orion-application/lib/orion-requestor';
import { injectIntl, intlShape } from 'react-intl';

import AssessmentList from '../AssessmentList/AssessmentList';
import ContentContainer from 'terra-content-container';
import { useDispatch, useSelector } from 'react-redux';
// import { getmdsStatus,updateMdsStatusParams} from '../../state/patientDetailActions';
// import { getAssessmentListSuccess } from '../../state/assessmentListActions';
import MultiSelectField from 'terra-form-select/lib/MultiSelectField';
import mockMdsStatus from '../../../../data/mock/mds-status.json'


const cx = classNames.bind(styles);

export function AssessmentFilter() {
  // const intl = React.useContext(ApplicationIntlContext);

  const dispatch = useDispatch();
  // const orionRequestor = useContext(OrionRequestorContext);
  const { mockMdsStatusData, mdsStatusFilters, mdsStatusFilters: {isMdsStatusLoading = false } }= useSelector(state => state.PatientDetail);
  // const {assessmentList, hasError, isAssessmentListLoading, isAssessmentSuccess, errorMessage} = useSelector(state=>state.assessmentList);
  console.log(mdsStatusFilters);
  console.log(mockMdsStatusData);


  


  const getAssessmentList = () => {
  //   const [assessment, setassessment] = useState(assessmentList);
  
  //   const [mdsfilters, setMdsFilters] = useState(mockMdsStatus);
  
  //   // Function to handle filter changes
  //   const handleFilterChange = (e) => {
  //     const { name, value } = e.target;
  
  //     setMdsFilters((prevFilters) => ({
  //       ...prevFilters,
  //       [name]: value,
  //     }));
  //   };

  //   // Function to apply filters and get the filtered assessment list
  //   const getFilteredAssessments = () => {
  //     let filteredList = assessment;
  
  //     if (mdsfilters.mdsStatus) {
  //       filteredList = filteredList.filter((assessment) => assessment.mdsStatus === mdsfilters.mdsStatus);
  //     }
  
  //     return filteredList;
    };
  //   const filteredPatients = getFilteredAssessments();


  // Update Assessment list with default params
  useEffect(()=>{
    getAssessmentList();
  },[]);
  




  // const headerTitle = intl.formatMessage({ id: 'RESIDENT_VIEW_TITLE' });

  const addOverlay = () => {
    return (
      <LoadingOverlay
      // isOpen={isMdsStatusLoading}
        isAnimated
        isRelativeToContainer={true}
        zIndex="6000"
      />
    );
  }


  const testStatus = mockMdsStatusData.length>0?[{id:'5466745',mdsStatus:'ALL'},...mockMdsStatusData]:mockMdsStatusData;
  // console.log(testStatus);
  //header={<Header title={headerTitle} 
 return(
  <ContentContainer>
  <OverlayContainer overlay={addOverlay()}>
  <div className={cx('Assessment-filter-container')}>
    <DatePickerField
          required
          label="ARD Start Date"
          name="date-input"
          datePickerId="startDate"
          selectedDate={mdsStatusFilters.ardStartDate}
          isInvalid = {!mdsStatusFilters.ardStartDate}
          error={"Please select start date"} 
          />
    <DatePickerField
          required
          label="ARD End Date"
          name="date-input"
          datePickerId="EndDate"
          selectedDate={mdsStatusFilters.ardEndDate}
          isInvalid = {!mdsStatusFilters.ardEndDate}
          error={"Please select start date"}
        
          />
          <br/>

    <MultiSelectField
          required
          maxWidth="50%"
          label="MDS Status"
          // isInvalid = {!statusFilters.mdsStatusId}
          
          error={"Please select mds status"}
          defaultValue={testStatus[0].mdsStatus}
          className={cx('form-multi-select')}
          placeholder="Select MDS status"

          >
           
            {
              testStatus.map(option => {
                return<MultiSelectField.Option value={option.id} display={option.mdsStatus} key={option.id} />
              })
            }
     </MultiSelectField>
    <Button text="Apply" variant="action" className={cx('button')} onClick={getAssessmentList} />
   
  </div>
  <AssessmentList/>
  </OverlayContainer>
  </ContentContainer>
 );

}


export default AssessmentFilter;


