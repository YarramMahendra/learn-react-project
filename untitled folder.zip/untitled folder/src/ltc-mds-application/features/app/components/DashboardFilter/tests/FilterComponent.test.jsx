import React from 'react';

import {FilterComponent} from '../FilterComponent';

describe('<FilterComponent />', () => {});
