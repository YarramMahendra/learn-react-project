import React from 'react';

import {AssessmentList} from '../AssessmentList';

describe('<AssessmentList />', () => {});
