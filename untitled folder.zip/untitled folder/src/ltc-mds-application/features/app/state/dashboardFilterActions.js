import {
  SET_USER_FACILITIES_SUCCESS,
  SET_USER_FACILITIES_FAIL,
  SET_LOCATION_LIST_SUCCESS,
  SET_LOCATION_LIST_FAIL,
  SET_FILTER_PARAMS,
  SET_FILTER_LOADING,
  GET_SELEECTED_PATIENT_LOADING
} from '../../../constants/ActionTypes';
import { AppConstants } from '../../../constants/AppConstants';

const jsonHeaders = (_requestData, headers) => {
  headers.Accept = "application/json";
};
const MAX_RETRIES = 0;

function constructUrl(url,...params) {
    return url;
  }

export function getUserFacilities(baseUrl, orionRequestor) {
    var url = constructUrl(baseUrl);
    // log.info("get facilities for logged in User " + url);
    return dispatch => {
        dispatch(updateFiltersLoading(true));
        const { request } = orionRequestor.get({
        url: url
        });
        request
        .then(response => {
            // log.info(JSON.stringify(response));
            //for mock data
            const facilities = response.data.data.mockFacilities.facilities;
            //for real api call
            // const facilities = response.data.facilities;
            var locUrl = `/facilities/${facilities[0].id}/locations`;
            const { request } = orionRequestor.get({
              url: locUrl
            });

            request
              .then(locationsData=>{
                //for mock data
                const locations = locationsData.data.data.mockLocations.locations;
                //for real api call
                // const locations = locationsData.data.locations;
                dispatch(getUserFacilitiesSuccess(facilities, locations))
              })
              .catch(error=>{
                return dispatch(getUserFacilitiesFailure(error));
              })
        })
        .catch(error => {
            // log.error(JSON.stringify(error));
            return dispatch(getUserFacilitiesFailure(error));
        });
    };
  }

const getUserFacilitiesSuccess = (data, locationsData=[]) => {
  return {
    type: SET_USER_FACILITIES_SUCCESS,
    payload: {
      userFacilities: data,
      nurseUnits: locationsData
    }
  };
};

const getUserFacilitiesFailure = data => {
  return {
    type: SET_USER_FACILITIES_FAIL,
    payload: {}
  };
};

export function getLocations(baseUrl,facility, orionRequestor) {
    var facility = facility[0];
    baseUrl = `/facilities/${facility.id}/locations`;
    var url = constructUrl(baseUrl,facility.id);
    // log.info("get facilities for logged in User " + url);
    return dispatch => {
        dispatch(updateFiltersLoading(true));
        const { request } = orionRequestor.get({
        url: baseUrl
        });
        request
        .then(response => {
            dispatch(getLocationsSuccess(response.data, facility));
        })
        .catch(error => {
            // log.error(JSON.stringify(error));
            return dispatch(getLocationsFailure(error));
        });
    };
}

const getLocationsSuccess = (data, facility) => {
  return {
    type: SET_LOCATION_LIST_SUCCESS,
    payload: {
      locationList: data.locations,
      filters: {
        facilityId:facility.id,
        timeZone: facility.timeZone
      }
    }
  };
};

const getLocationsFailure = data => {
  return {
    type: SET_LOCATION_LIST_FAIL,
    payload: {}
  };
};

export function updateFilterParams(params) {
  return {
    type:SET_FILTER_PARAMS,
    payload: {
      facilityId:params.facilityId,
      nurseUnits: params.nurseUnits,
      startDate:params.startDate,
      endDate: params.endDate,
      timeZone:params.timeZone,
      reportType: AppConstants.REPORT_TYPE.ADMISSION
    }
  }
}

export function updateFiltersLoading(isLoading) {
  return {
    type: SET_FILTER_LOADING,
    payload: {
      loading: isLoading
    }
  };
}

// export function selectedPatientLoading(isLoading) {
//   return {
//     type: GET_SELEECTED_PATIENT_LOADING,
//     payload: {
//       loading: isLoading
//     }
//   };
// }
export function selectedPatientLoading(isLoading) {
  return {
    type: GET_SELEECTED_PATIENT_LOADING,
    payload: {
      loading: isLoading
    }
  };
}

/** set selected patient */

