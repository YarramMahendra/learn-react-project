import React from 'react';
import { LtcMdsApplicationView } from '../../ltc-mds-application/features/app';

export default () => (
  <LtcMdsApplicationView />
);
