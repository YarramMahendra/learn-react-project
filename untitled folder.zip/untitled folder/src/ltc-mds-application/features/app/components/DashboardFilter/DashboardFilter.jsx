import React, { useContext, useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { OrionRequestorContext } from 'orion-application/lib/orion-requestor';

import SearchSelectField from 'terra-form-select/lib/SearchSelectField';
import MultiSelectField from 'terra-form-select/lib/MultiSelectField';
import DatePickerField from 'terra-date-picker/lib/DatePickerField';
import Button from 'terra-button';

import LoadingOverlay from 'terra-overlay/lib/LoadingOverlay';
import OverlayContainer from 'terra-overlay/lib/OverlayContainer';

import classNames from 'classnames/bind';
import { useDispatch, useSelector } from 'react-redux';
import { getLocations, updateFilterParams } from '../../state/dashboardFilterActions';
import { getPatientList } from '../../../patient/state/patientListActions';

import styles from './DashboardFilter.scss';

const cx = classNames.bind(styles);

const DashboardFilter = () => {
  const dispatch = useDispatch();
  const orionRequestor = useContext(OrionRequestorContext);

  const { userFacilities, locations, filters, filters: {isFilterLoading=false} } = useSelector(state => state.dashboardFilter);

  //Update patient list with default params
  useEffect(()=>{
    updatePatientList();
  },[]);

  const handleDateChange = (event, dateValue, fieldName) => {
    dispatch(updateFilterParams({
      ...filters,
      [fieldName]: dateValue
    }));
  };

  const handleDateChangeRaw = (event, dateValue, metadata,fieldName) => {
    if (!metadata.isValidValue) {
      dispatch(updateFilterParams({
        ...filters,
        [fieldName]: dateValue,
        ['is'+fieldName+'Invalid']: true
      }));
    }
  };

  /**When facility is changed update location and then update filters in reducer store */
  const setSelectValue = (value) => {
    const facility = userFacilities.filter(facility=>facility.id==value);
    dispatch(getLocations(
      `/facilities/${value.id}/locations`,
      facility,
      orionRequestor
    ));
  }

  const setMultiSelectValue = (value) => {
    if(value.includes('ALL')){
      var allNurseUnits = locations.map(location=>location.id);
      value = [...allNurseUnits,'ALL'];
    }
    dispatch(updateFilterParams({
      ...filters,
      nurseUnits:value
    }));
  }

  //update patient list on updating the filter
  const updatePatientList = () => {
    if(validateFilter()){
      dispatch(getPatientList(filters,orionRequestor));
    }
  }

  const locationDropDownOptions = locations.length>0?[{id:'ALL',name:'ALL'},...locations]:locations;

  const addOverlay = () => {
    return (
      <LoadingOverlay
        isOpen={isFilterLoading}
        isAnimated
        isRelativeToContainer={true}
        zIndex="6000"
      />
    );
  }

  const validateFilter = () => {
    return filters.facilityId && filters.nurseUnits.length > 0 && filters.startDate != null && filters.endDate != null;
  }

  return (
    <OverlayContainer overlay={addOverlay()}>
      <div className={cx('dashboard-filter-container')} >
        <SearchSelectField
          required
          maxWidth="10%"
          label="Facility"
          isInvalid = {!filters.facilityId}
          error={"Please select a facility"}
          selectId="facility-dropdown"
          placeholder="Select a facility"
          className={cx('form-select')} 
          defaultValue={filters.facilityId}
          onChange={(value)=>{
            setSelectValue(value)
          }}>
          {
            userFacilities.map(option=>{
              return <SearchSelectField.Option value={option.id} display={option.name} key={option.id} />
            })
          }
        </SearchSelectField>

        <br />
        <MultiSelectField 
          required
          label="Location(s)"
          maxWidth="10%"
          selectId="nurseunit-dropdown"
          isInvalid = {filters.nurseUnits.length == 0}
          error={"Please select a location(s)"}
          placeholder="Select location(s)"
          className={cx('form-multi-select')} 
          value={filters.nurseUnits.includes('ALL')? ['ALL'] : filters.nurseUnits} 
          onChange={(value)=>{
            setMultiSelectValue(value)
          }}>
          {
            locationDropDownOptions.map(option=>{
              return <MultiSelectField.Option value={option.id} display={option.name} key={option.id} />
            })
          }
        </MultiSelectField>
        <br />
        <DatePickerField
          required
          label="Adm Start Date"
          name="date-input"
          datePickerId="startDate"
          isInvalid = {!filters.startDate}
          error={"Please select start date"}
          selectedDate={filters.startDate}
          onChange={(event, dateValue)=>handleDateChange(event,dateValue,'startDate')}
          onChangeRaw={(event, dateValue, metadata)=>handleDateChangeRaw(event,dateValue,metadata,'startDate')}
        />
        <DatePickerField
          required
          label="Adm End Date"
          name="date-input"
          datePickerId="endDate"
          minDate={filters.startDate}
          isInvalid = {!filters.endDate}
          error={"Please select end date"}
          selectedDate={filters.endDate}
          onChange={(event, dateValue)=>handleDateChange(event,dateValue,'endDate')}
          onChangeRaw={(event, dateValue, metadata)=>handleDateChangeRaw(event,dateValue,metadata,'endDate')}
        />
        <Button text="Apply" variant="action" isDisabled={!validateFilter()} className={cx('button')} onClick={updatePatientList} />
      </div>
    </OverlayContainer>
  );
}

export default DashboardFilter;
