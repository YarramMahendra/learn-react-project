// // eslint-disable-next-line import/no-extraneous-dependencies
// const { config } = require('@cerner/terra-functional-testing/lib/config/wdio.conf');

// exports.config = config;

const { config } = require('@cerner/terra-functional-testing/lib/config/wdio.conf');

exports.config = config;
