
/** Dispatch assessments for selected patient */
import {SET_MDS_STATUS_SUCCESS,
  SET_MDS_STATUS_FAIL,
  SET_MDS_STATUS_FILTER_PARAMS,
  SET_MDS_STATUS_FILTER_LOADING
       } from '../../../constants/ActionTypes';
import { AppConstants } from '../../../constants/AppConstants';
import {mdsStatusOptions} from  '../../../data/mock/mds-status.json';





// // tried other way to fetch data fro json file
//   export const getMdsStatus = () => {
//     return  (dispatch) => {
//       try {
//         // Make an API call or fetch JSON data from a file
//         // const response = await fetch('../../../data/mock/mds-status.json');
//         // if (!response.ok) {
//         //   throw new Error('Failed to fetch data');
//         // }
//         // Parse the JSON response
//         // const mdsStatusData = await response.json();
  
//         // Dispatch an action with the mapped data
//         // dispatch({ type: 'getMdsStatusSuccess', payload: mdsStatusData });
//         dispatch(getMdsStatusSuccess(mdsStatusOptions))
//       } catch (error) {
//         // Dispatch an action to handle the error
//         dispatch(getMdsStatusFailure(error));
//       }
      
//     };
//   };


// const getMdsStatusSuccess = (mdsStatusOptions=[]) => {
//   return {
//     type: SET_MDS_STATUS_SUCCESS,
//     payload: {
//       mdsStatusOptions:mockMdsStatusData
//     }
//   };
// };

// const getMdsStatusFailure = data => {
//   return {
//     type: SET_MDS_STATUS_FAIL,
//     payload: {}
//   };
// };

// export function updateMdsStatusParams(params) {
//   return {
//     type:SET_MDS_STATUS_FILTER_PARAMS,
//     payload: {
//       mdsStatusId:params.mdsStatusId,
//       ardStartDate:params.ardStartDate,
//       ardEndDate: params.ardEndDate,
//     }
//   }
// }

// export function updateMdsStatusFiltersLoading(isLoading) {
//   return {
//     type: SET_MDS_STATUS_FILTER_LOADING,
//     payload: {
//       loading: isLoading
//     }
//   };
// }






