import {
    GET_ASSESSMENT_LIST_SUCCESS,
    GET_ASSESSMENT_LIST_FAIL,
    SET_ASSESSMENT_LIST_LOADING
  } from '../../../constants/ActionTypes';
import { AppConstants } from '../../../constants/AppConstants';
import { convertToUTCDateTime } from '../../../utils/DateTimeUtil';
import {mockAssessments} from '../../../data/mock/assessment-list.json';
 
  const MAX_RETRIES = 0;
  
  // 
  export function getPatientList(mdsStatusFilters) {
    
   
    return dispatch => {
        dispatch(updatePatientListLoading(true));
        
        request
        .then(response => {
          //for mock data
          const assessmentList = mockAssessments.assessmentData;
          //for actual api calls
          // const patients = response.data.recordData.patients;
           dispatch(getAssessmentListSuccess(assessmentList));
        })
        .catch(error => {
            // log.error(JSON.stringify(error));
            return dispatch(getAssessmentListFailure(error));
        });
    };
  }
  
  
  const getAssessmentListSuccess = (assessmentList) => {
    return {
      type: GET_ASSESSMENT_LIST_SUCCESS,
      payload: {
        assessmentList
      }
    };
  };
  const getAssessmentListFailure = assessmentList => {
    return {
      type: GET_ASSESSMENT_LIST_FAIL,
      payload: {}
    };
  };
  
  export function updateAssessmentListLoading(isLoading) {
    return {
      type: SET_ASSESSMENT_LIST_LOADING,
      payload: {
        loading: isLoading
      }
    };
  }
