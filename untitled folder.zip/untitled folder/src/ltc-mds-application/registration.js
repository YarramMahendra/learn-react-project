import ReactOnRails from "react-on-rails";
import LtcMdsApplicationApplication from "./features/app/components/LtcMdsApplicationApplication";

ReactOnRails.register({
    LtcMdsApplicationApplication
});
