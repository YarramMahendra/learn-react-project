export { default as MdsDashboard } from './MdsDashboard';
