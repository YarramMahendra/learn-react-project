import React from 'react';

import {Assessment} from '../Assessment';

describe('<Assessment />', () => {});
