const {merge} = require('webpack-merge');
const { OrionDevSitePlugin } = require('orion-dev-site-plugin');
const WebpackConfigTerra = require('@cerner/webpack-config-terra');
const {
  DirectorySwitcherPlugin,
  LocalPackageAliasPlugin,
  TerraDevSiteEntrypoints,
  TerraDevSite,
} = require('terra-dev-site');

/**
 * Generates the file representing app name configuration.
 */

// const aggregateTranslations = require('@cerner/terra-aggregate-translations');

// const aggregateOptions = {
//   baseDir: __dirname,
//   excludes: ['./node_modules/packageToExclude'],
//   locales: ['en', 'en-US'],
//   format: 'es6',
// };

// aggregateTranslations(aggregateOptions);

const devSiteConfig = (env = {}, argv = { p: false }) => {
  const production = argv.p;

  return {
    entry: TerraDevSiteEntrypoints,
    plugins: [
      new TerraDevSite({
        env,
        sites: [OrionDevSitePlugin],
        defaultLocale: env.defaultLocale,
      }),
    ],
    resolve: {
      plugins: [
        new DirectorySwitcherPlugin({
          shouldSwitch: !production,
        }),
        new LocalPackageAliasPlugin(),
      ],
    },
  };
};

const mergedConfig = (env, argv) => merge(WebpackConfigTerra(env, argv), devSiteConfig(env, argv));

module.exports = mergedConfig;
