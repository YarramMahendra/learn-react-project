import React, { useContext, useState, useEffect } from 'react';
import { useDispatch,useSelector } from "react-redux";

import { OrionRequestorContext } from 'orion-application/lib/orion-requestor';
import { ApplicationIntlContext } from 'orion-application/lib/application-intl';
import ApplicationLoadingOverlay from 'orion-application/lib/application-loading-overlay';
import StatusView from 'terra-status-view';

import LtcMdsApplicationView from './LtcMdsApplicationView';
import { getUserFacilities } from '../state/dashboardFilterActions';
// import { getmdsStatus } from '../../patient/state/patientDetailActions';

/**
 * A component container used to retrieve facilities for logged in user
 */
const LtcMdsApplicationContainer = () => {
  // Use Orion Requestor to make services calls. Orion Requestor is provided via context by orion application.
  const orionRequestor = useContext(OrionRequestorContext);
  // Internationalization is provided via context by orion application.
  const intl = React.useContext(ApplicationIntlContext);

  const dispatch = useDispatch();
  const dashboardFilter = useSelector(state => state.dashboardFilter);
  const PatientDetail = useSelector(state => state.PatientDetail);

  /**
   * Fetch facilities data prior to mounting the view.
   * Note: The usage of empty brackets in the useEffect hook ensures the request is only made on the initial mount.
   */
  useEffect(() => {
    dispatch(getUserFacilities('/facilities',orionRequestor));
  }, [orionRequestor]);
  



  const { isLoading, hasError, errorMessage } = dashboardFilter;PatientDetail;
  


  // If the data retrieval was unsuccessful render an error view.
  if (hasError) {
    const errorMessageIntl = intl.formatMessage({ id: errorMessage });
    return <StatusView variant="error" message={errorMessageIntl} isGlyphHidden />;
  }

  // Display a loading indicator to the user while the data is retrieved.
  if (isLoading) {
    return <ApplicationLoadingOverlay isOpen backgroundStyle="clear" />;
  }

  // If the data retrieval was successful render the view.
  return <LtcMdsApplicationView />;
};

export default LtcMdsApplicationContainer;
