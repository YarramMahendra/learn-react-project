// eslint-disable-next-line import/no-extraneous-dependencies
const aggregateTranslations = require('@cerner/terra-aggregate-translations');

module.exports = () => {
  aggregateTranslations();
};
