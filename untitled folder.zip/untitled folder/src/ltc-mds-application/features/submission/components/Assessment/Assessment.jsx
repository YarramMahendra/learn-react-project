import React from 'react';
import PropTypes from 'prop-types';

import styles from './Assessment.scss';

const propTypes = {
  prop: PropTypes.string
}

const Assessment = ({prop = 'default value'}) => {
  return <div className={styles.Assessment}>Assessment {prop}</div>;
}

Assessment.propTypes = propTypes;

export default Assessment;